package com.t3h.demo;

public class Main {
    public static void main(String[] args) {
        MyString myString = new MyString("Hello java android");
//        System.out.println(myString.sort());
        System.out.println(myString.upWord());
    }
}
