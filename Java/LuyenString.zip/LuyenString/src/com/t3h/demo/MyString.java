package com.t3h.demo;

public class MyString {
    private String value;
    public MyString(String value){
        this.value = value;
    }

    public String sort(){
        String newValue = value;
        for ( int i = 0; i < newValue.length()-1; i++){
            for ( int j = i+1; j < newValue.length(); j++){
                char c1 = newValue.charAt(i);
                char c2 = newValue.charAt(j);
                if ( c1 > c2){
                    newValue = newValue.substring(0, i)+c2+
                            newValue.substring(i+1, j)+c1+
                            newValue.substring(j+1);
                }
            }
        }
        return newValue;
    }

    public String upWord(){
        value+=" ";
        int start = 0;
        String result = "";
        for ( int i = 0; i < value.length(); i++){
            if (value.charAt(i) == ' '){
                String v = value.substring(start, i);
                char c = v.charAt(0);
                v = (c+"").toUpperCase() +
                        v.substring(1);
                result+=(" " + v);
                start=i+1;
            }
        }

        return result;
    }

    public String revertString(String content){
        String result = "";
        for ( int i = 0; i < content.length(); i++){
            result = content.charAt(i)+result;
        }
        return result;
    }

    public String revertWord(String value){
        value = value +" ";
        int start = 0;
        String result = "";
        for ( int i = 0; i < value.length(); i++){
            if (value.charAt(i) == ' '){
                String v = value.substring(start, i);
                v = revertString(v);
                result = result+" " +v;
                start = i+1;
            }
        }
        return result;
    }



}
