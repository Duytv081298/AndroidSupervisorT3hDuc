package com.t3h.demorecycleview

data class RssData(var title:String,
                   var description:String,
                   var img:String?) {
}