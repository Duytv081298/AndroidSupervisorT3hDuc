package com.example.updateviewmodel.model

class SongSearch {
    var id = ""
    var linkImage:String = ""
    var songName:String = ""
    var artistName:String? = ""
    var linkSong:String? = ""
    var linkMusic:String? = ""
}